const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./db/sqlite.db');

// Create User Table
db.run(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT,
    email TEXT UNIQUE,
    password TEXT
  )
`);



// Create Todo Table
db.run(`
  CREATE TABLE IF NOT EXISTS todos (
    id TEXT PRIMARY KEY,
    title TEXT,
    description TEXT,
    status TEXT,
    userId TEXT,
    FOREIGN KEY (userId) REFERENCES users(id)
  )
`);




const jwt = require('jsonwebtoken');
require('dotenv').config();

module.exports = (req, res, next) => {
  const token = req.header('Authorization');

  if (!token) return res.status(401).send("Access denied. No token provided.");

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(400).send("Invalid token.");
  }
};



const bcrypt = require('bcryptjs');
c

// Register User
exports.signup = async (req, res) => {
  const { name, email, password } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  const userId = uuidv4();
  db.run(`INSERT INTO users (id, name, email, password) VALUES (?, ?, ?, ?)`,
    [userId, name, email, hashedPassword], (err) => {
      if (err) return res.status(400).json({ error: err.message });

      const token = jwt.sign({ id: userId }, process.env.JWT_SECRET, {
        expiresIn: '1h',
      });

      res.json({ token });
    });
};

// Login User
exports.login = async (req, res) => {
  const { email, password } = req.body;

  db.get(`SELECT * FROM users WHERE email = ?`, [email], async (err, user) => {
    if (!user) return res.status(400).json({ error: 'User not found' });

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).json({ error: 'Invalid password' });

    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });

    res.json({ token });
  });
};


// Get all todos
exports.getTodos = (req, res) => {
  const userId = req.user.id;

  db.all(`SELECT * FROM todos WHERE userId = ?`, [userId], (err, rows) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ todos: rows });
  });
};

// Create new todo
exports.createTodo = (req, res) => {
  const { title, description, status } = req.body;
  const userId = req.user.id;
  const todoId = uuidv4();

  db.run(`INSERT INTO todos (id, title, description, status, userId) VALUES (?, ?, ?, ?, ?)`,
    [todoId, title, description, status, userId], (err) => {
      if (err) return res.status(400).json({ error: err.message });
      res.json({ message: "Todo created successfully" });
    });
};

// Update a todo
exports.updateTodo = (req, res) => {
  const { id } = req.params;
  const { title, description, status } = req.body;

  db.run(`UPDATE todos SET title = ?, description = ?, status = ? WHERE id = ?`,
    [title, description, status, id], (err) => {
      if (err) return res.status(400).json({ error: err.message });
      res.json({ message: "Todo updated successfully" });
    });
};

// Delete a todo
exports.deleteTodo = (req, res) => {
  const { id } = req.params;

  db.run(`DELETE FROM todos WHERE id = ?`, [id], (err) => {
    if (err) return res.status(400).json({ error: err.message });
    res.json({ message: "Todo deleted successfully" });
  });
};

const express = require('express');
const router = express.Router();
const { signup, login } = require('../controllers/authController');

router.post('/signup', signup);
router.post('/login', login);




const { getTodos, createTodo, updateTodo, deleteTodo } = require('../controllers/todoController');
const authMiddleware = require('../middleware/authMiddleware');

router.get('/todos', authMiddleware, getTodos);
router.post('/todos', authMiddleware, createTodo);
router.put('/todos/:id', authMiddleware, updateTodo);
router.delete('/todos/:id', authMiddleware, deleteTodo);



const bodyParser = require('body-parser');
const authRoutes = require('./routes/authRoutes');
const todoRoutes = require('./routes/todoRoutes');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());

app.use('/api/auth', authRoutes);
app.use('/api', todoRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});